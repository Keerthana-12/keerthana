import { Component, OnInit } from '@angular/core';
import { IProduct } from './product.interface';
import { ProductService } from './product.service';

@Component({
  selector: 'app-product-search',
  templateUrl: './product-search.component.html',
  styleUrls: ['./product-search.component.css']
})
export class ProductSearchComponent implements OnInit {

  products:IProduct[];
  constructor(private productservice:ProductService) { }

  ngOnInit() {
  }
  onSearch(value){
    console.log(value);
    this.products=this.productservice.searchProduct(value.searchTerm);
  }

}
