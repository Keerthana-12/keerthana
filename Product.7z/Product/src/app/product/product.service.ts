import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { IProduct } from './product.interface';
import { throwError } from 'rxjs';
import {catchError} from 'rxjs/operators'


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  products:IProduct[];
  constructor(private http:HttpClient) {
    this.http.get<IProduct[]>("assets/product.json")
    .pipe(catchError(this.handleError))
    .subscribe(data=>this.products=data, error=>console.log(error));

   }
   handleError (errorREsponse:HttpErrorResponse){
     console.log("An Error Occured"+errorREsponse.error.message);
     return throwError ("An error Occuer Try Again later")
   }
   getProducts():IProduct[]{
     return this.products;
   }
   deleteProduct(id:number){
     this.products=this.products.filter(p=>p.id!==id);
   }

   searchProduct(searchText:string){
     let prods:IProduct[] =this.products
     .filter(p=>p.name.toLowerCase()===searchText.toLowerCase());
     if(prods.length==0){
       prods=this.products.filter
       (p=>p.category.toLowerCase()===searchText.toLowerCase());
     }
     return prods;
   }
}
