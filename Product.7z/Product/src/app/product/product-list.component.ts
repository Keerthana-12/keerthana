import { Component, OnInit } from '@angular/core';
import { IProduct } from './product.interface';
import { ProductService } from './product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products:IProduct[];
  constructor(private productservice:ProductService) { }

  ngOnInit() {
    setTimeout(() => {
      this.products=this.productservice.getProducts();
    }, 10);
    
  }
  onDelete(id:number){
    this.productservice.deleteProduct(id);
    this.products=this.productservice.getProducts();    
  }

}
