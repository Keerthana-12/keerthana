import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductListComponent } from './product/product-list.component';
import { ProductSearchComponent } from './product/product-search.component';


const routes: Routes = [
  {path:"list", component:ProductListComponent},
  {path:"Search", component:ProductSearchComponent},
  {path:' ',redirectTo:'/search',pathMatch:"full"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
