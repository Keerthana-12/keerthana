package com.steps;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.registrationpom.EducationDetails;
import com.registrationpom.PresonalDetails;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	WebDriver driver;
	PresonalDetails details;
	EducationDetails education;
	
	@Before
	public void setup() {
		   System.setProperty("webdriver.chrome.driver", "C:\\Users\\CBANGARR\\Downloads\\chromedriver.exe");
		   driver=new ChromeDriver();
		  details=new PresonalDetails(driver);
		   education=new EducationDetails(driver);
	}
	@Given("^User is on Registration Page for Personal and Education Details$")
	public void user_is_on_Registration_Page_for_Personal_and_Education_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   driver.get("///C:/Users/CBANGARR/Desktop/set%20b/PersonalDetails.html");
	}

	@Then("^the title should be (.*)$")
	public void the_title_should_be(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
		assertEquals(arg1, title);
	}

	@When("^Next link is clicked without entering the Firstname$")
	public void next_link_is_clicked_without_entering_the_Firstname() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 details.next().click();
	}

	@Then("^error message should be displayed as 'Please fill the First Name'$")
	public void error_message_should_be_displayed_as_Please_fill_the_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill the First Name", alert.getText());
	   alert.accept();
	}

	@When("^Next link is clicked without entering the Lastname$")
	public void next_link_is_clicked_without_entering_the_Lastname() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		details.firstname().sendKeys("Surya");
		  details.next().click();
	}

	@Then("^error message should be displayed as 'Please fill the Last Name'$")
	public void error_message_should_be_displayed_as_Please_fill_the_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill the Last Name", alert.getText());
	   alert.accept();
	}

	@When("^Next link is clicked without entering the Email$")
	public void next_link_is_clicked_without_entering_the_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 details.lastname().sendKeys("Chopperla");			
			 details.next().click();
	}

	@Then("^error message should be displayed as 'Please fill the Email'$")
	public void error_message_should_be_displayed_as_Please_fill_the_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill the Email", alert.getText());
		 alert.accept();
	}

	@When("^Next link is clicked without entering the ContactNo\\.$")
	public void next_link_is_clicked_without_entering_the_ContactNo() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 details.email().sendKeys("chopperlasurya6@gmail.com");
		   details.next().click();
	}
	@Then("^alert message should be displayed as 'Please fill the Contact No\\.'$")
	public void alert_message_should_be_displayed_as_Please_fill_the_Contact_No() throws Throwable {
		Alert alert = driver.switchTo().alert();
		assertEquals("Please fill the Contact No.", alert.getText());
	    alert.accept();
	    details.getPhone().sendKeys("646651");
	  }
	@When("^Next button is clicked without entering Valid Contact Number$")
	public void next_button_is_clicked_without_entering_Valid_Contact_Number() throws Throwable {
		details.next().click();
	}

	@Then("^error message should be displayed as 'Please fill the Contact No\\.'$")
	public void error_message_should_be_displayed_as_Please_fill_the_Contact_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill the Contact No.", alert.getText());
		alert.accept();
	}

	@When("^Next link is clicked without entering the Address(\\d+)$")
	public void next_link_is_clicked_without_entering_the_Address(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		details.phone().sendKeys("9789997486");
		//registration.address1().sendKeys("");
	  details.next().click();
	}

	@Then("^error message should be displayed as 'Please fill the address line (\\d+)'$")
	public void error_message_should_be_displayed_as_Please_fill_the_address_line(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill the address line 1", alert.getText());
		alert.accept();
	}

	@When("^user clicks next link without entering the Address(\\d+)$")
	public void user_clicks_next_link_without_entering_the_Address(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 details.address1().sendKeys("Chennai");
		   // registration.address2().sendKeys("");
		    details.next().click();
	}

	@Then("^error message should  display as 'Please fill the address line (\\d+)'$")
	public void error_message_should_display_as_Please_fill_the_address_line(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill the address line 2", alert.getText());
		alert.accept();
	}

	@When("^Next Link is clicked without selecting the city$")
	public void next_Link_is_clicked_without_selecting_the_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		details.address2().sendKeys("MIPL");
		details.next().click();
	}

	@Then("^error message should be displayed as 'Please select city'$")
	public void error_message_should_be_displayed_as_Please_select_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Please select city", alert.getText());
		alert.accept();
	}

	@When("^Next Link is clicked without selecting  the State$")
	public void next_Link_is_clicked_without_selecting_the_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		details.city().click();
		details.next().click();
	}

	@Then("^error message should be displayed as 'Please select state'$")
	public void error_message_should_be_displayed_as_Please_select_state() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Please select state", alert.getText());
		alert.accept();
	}

	@When("^Next Link is clicked it Should  navigate to the next page$")
	public void next_Link_is_clicked_it_Should_navigate_to_the_next_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		details.state().click();
		details.next().click();
	}

	@Then("^message should be displayed as 'Personal details are validated and accepted successfully\\.'$")
	public void message_should_be_displayed_as_Personal_details_are_validated_and_accepted_successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Personal details are validated and accepted successfully.", alert.getText());
		alert.accept();
	}
	@Given("^User is on Educational details Form page$")
	public void user_is_on_Educational_details_Form_page() throws Throwable {
	    driver.get("file:///C:/Users/CBANGARR/Desktop/set%20b/EducationalDetails.html");
	}

	@Then("^Title should be 'Education Details'$")
	public void title_should_be_Education_Details() throws Throwable {
		assertEquals("Educational Details", driver.getTitle());
	 
	}
	
	@When("^Register button is clicked without entering the Graduation$")
	public void register_button_is_clicked_without_entering_the_Graduation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		education.registerMe().click();
	}

	@Then("^error message should be displayed as 'Please Select Graduation'$")
	public void error_message_should_be_displayed_as_Please_Select_Graduation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Please Select Graduation", alert.getText());
		alert.accept();
	}

	@When("^Register button is clicked without entering the Percentage$")
	public void register_button_is_clicked_without_entering_the_Percentage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		  education.graduation().click();
		   // education.percentage().sendKeys("");
		    education.registerMe().click();

	}

	@Then("^error message should be displayed as 'Please fill Percentage detail'$")
	public void error_message_should_be_displayed_as_Please_fill_Percentage_detail() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill Percentage detail", alert.getText());
		alert.accept();
	}

	@When("^Register button is clicked without entering the PassingYear$")
	public void register_button_is_clicked_without_entering_the_PassingYear() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 education.percentage().sendKeys("98");
			//education.passingyear().sendKeys("");
			education.registerMe().click();
	}

	@Then("^error message should be displayed as 'Please fill Passing Year'$")
	public void error_message_should_be_displayed_as_Please_fill_Passing_Year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill Passing Year", alert.getText());
		alert.accept();
	}

	@When("^Register button is clicked without entering the ProjectName$")
	public void register_button_is_clicked_without_entering_the_ProjectName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		education.passingyear().sendKeys("2019");
		//education.projectname().sendKeys("");
		education.registerMe().click();
	}

	@Then("^error message should be displayed as 'Please fill Project Name'$")
	public void error_message_should_be_displayed_as_Please_fill_Project_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill Project Name", alert.getText());
		alert.accept();
	}

	@When("^Register button is clicked without entering the Technologies Used$")
	public void register_button_is_clicked_without_entering_the_Technologies_Used() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 education.projectname().sendKeys("Capgemini");
		   education.registerMe().click();
	}

	@Then("^error message should be displayed as 'Please Select Technologies Used'$")
	public void error_message_should_be_displayed_as_Please_Select_Technologies_Used() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Please Select Technologies Used", alert.getText());
		alert.accept();
	}
	@When("^User enter valid details$")
	public void user_enter_valid_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    education.technologiesused().click();
	    education.otherTechnologies().sendKeys("testing");
	    education.registerMe().click();
	}

	@Then("^message should be displayed as 'Your Registration Has succesfully done Plz check you registerd email for account activation link !!!'$")
	public void message_should_be_displayed_as_Your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 Alert alert = driver.switchTo().alert();
	        assertEquals("Your Registration Has succesfully done Plz check you registerd email for account activation link !!!",alert.getText());
	        alert.accept();
	     
	}
    




}
