package com.registrationpom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PresonalDetails {
	WebDriver driver;
	
	public PresonalDetails(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[11]/td/a")
	WebElement next;
	
	@FindBy(id="txtFirstName")
	WebElement firstname;
	
	@FindBy(id="txtLastName")
	WebElement lastname;
	
	@FindBy(name="Email")
	WebElement email;
	
	@FindBy(name="Phone")
	WebElement phone;
		
	@FindBy(name="address1")
	WebElement address1;
	
	@FindBy(name="address2")
	WebElement address2;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[9]/td[2]/select/option[4]")
	WebElement city;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[10]/td[2]/select/option[3]")
	WebElement state;
	
	
	public WebElement next()
	{
		return next;	
	}
	
	
	public WebElement firstname()
	{
		return firstname;
	}
	
	
	public WebElement lastname()
	{
		return lastname;
	}
	
	public WebElement email()
	{
		return email;
	}
	public WebElement phone()
	{
		return phone;
	}
	public WebElement getPhone() {
		return phone;
	}
	public WebElement address1()
	{
		return address1;
	}
	
	public WebElement address2()
	{
		return address2;
	}
	
	public WebElement city()
	{
		return city;
	}
	
	public WebElement state()
	{
		return state;
	}
	
	

}
