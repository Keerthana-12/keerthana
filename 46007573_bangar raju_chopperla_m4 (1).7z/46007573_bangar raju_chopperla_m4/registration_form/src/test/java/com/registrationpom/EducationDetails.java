package com.registrationpom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EducationDetails {

	WebDriver driver;
	
	public EducationDetails(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="/html/body/form/table/tbody/tr[1]/td[2]/select/option[3]")
	WebElement graduation;
	
	@FindBy(name="percentage")
	WebElement percentage;
	
	@FindBy(name="passingYear")
	WebElement passingyear;
	
	@FindBy(name="projectName")
	WebElement projectname;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[3]")
	WebElement technologiesused;
	
	@FindBy(name="otherTechnologies")
	WebElement otherTechnologies;
	
	@FindBy(xpath="//*[@id=\"btnRegister\"]")
	WebElement registerMe;
		
	
	public WebElement registerMe()
	{
		return registerMe;	
	}
	
	public WebElement graduation()
	{
		return graduation;
	}
	
	
	public WebElement percentage()
	{
		return percentage;
	}
	
	public WebElement passingyear()
	{
		return passingyear;
	}
	public WebElement projectname()
	{
		return projectname;
	}
	public WebElement technologiesused()
	{
		return technologiesused;
	}
	
	public WebElement otherTechnologies()
	{
		return otherTechnologies;
	}
	
	
}
