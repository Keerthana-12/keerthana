import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductListComponent } from './product/product-list.component';
import { SearchProductComponent } from './product/search-product.component';
import { AddProductComponent } from './product/add-product.component';
import { ShowsearchProductComponent } from './product/showsearch-product.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    SearchProductComponent,
    AddProductComponent,
    ShowsearchProductComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
