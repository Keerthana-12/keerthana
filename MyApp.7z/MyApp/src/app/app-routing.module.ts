import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductListComponent } from './product/product-list.component';
import { AddProductComponent } from './product/add-product.component';
import { SearchProductComponent } from './product/search-product.component';
import { ShowsearchProductComponent } from './product/showsearch-product.component';


const routes: Routes = [
  {path:'list',component:ProductListComponent},
  {path:'add',component:AddProductComponent},
  {path:'search',component:SearchProductComponent},
  {path:'showSearch',component:ShowsearchProductComponent},
  {path:'',redirectTo:'/list',pathMatch:"full"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
