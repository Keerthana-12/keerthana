import { Component, OnInit } from '@angular/core';
import { IProducts } from './product.interface';
import { ProductService } from './product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search-product',
  templateUrl: './search-product.component.html',
  styleUrls: ['./search-product.component.css']
})
export class SearchProductComponent implements OnInit {
products:IProducts[];
  constructor(private productService:ProductService, private router:Router) { }

  ngOnInit() {
  }
  onSearch(value){
    this.products=this.productService.searchProduct(value.searchTerm);
    this.router.navigate(["/showSearch"]);
  }
 

}
