import { Component, OnInit } from '@angular/core';
import { IProducts } from './product.interface';
import { ProductService } from './product.service';

@Component({
  selector: 'app-showsearch-product',
  templateUrl: './showsearch-product.component.html',
  styleUrls: ['./showsearch-product.component.css']
})
export class ShowsearchProductComponent implements OnInit {
products:IProducts[];
  constructor(private productServie:ProductService) { }

  ngOnInit() {
    
    this.products=this.productServie.getSearchedProduct();
  }

}
