import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { IProducts } from './product.interface';
import { ProductService } from './product.service';


@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
products:IProducts[];
  constructor(private productService:ProductService, private router:Router) { }

  ngOnInit() {
  }
  onSubmit(product:IProducts){
    console.log(product);
    this.productService.addProduct(product);
    this.router.navigate(["/list"]);
  }

}
