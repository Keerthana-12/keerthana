import { Component, OnInit } from '@angular/core';
import { IProducts } from './product.interface';
import { ProductService } from './product.service';


@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
products:IProducts[];
  constructor(private productService:ProductService) { }

  ngOnInit() {
    setTimeout(()=>
    {this.products=this.productService.getProducts();},10);
  }
  onDelete(id:number){
    this.productService.deleteProduct(id);
    this.products=this.productService.getProducts();
  }

}
