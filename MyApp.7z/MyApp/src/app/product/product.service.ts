import { Injectable } from '@angular/core';
import { IProducts } from './product.interface';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  prods:IProducts[];
products:IProducts[]=[];
  constructor() { }
  getProducts():IProducts[]{
    return this.products;
  }
  deleteProduct(id:number){
    this.products=this.products.filter(pro=>pro.id!=id);
  }
  addProduct(product:IProducts){
    this.products.push(product);
    }
    searchProduct(SearchText:string){
       this.prods=this.products.filter(p=>p.name.toLowerCase()===SearchText.toLowerCase());
      if(this.prods.length===0){
        this.prods=this.products.filter(p=>p.brand.toLowerCase()===SearchText.toLowerCase());
      }
      return this.prods;
    }

    getSearchedProduct():IProducts[]
    {
      return this.prods;
    }

  
}
