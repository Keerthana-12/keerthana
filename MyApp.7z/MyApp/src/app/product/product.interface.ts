export interface IProducts{
    id:number;
    name:string;
    price:number;
    brand:string
}