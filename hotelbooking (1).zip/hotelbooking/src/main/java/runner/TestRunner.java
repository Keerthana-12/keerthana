package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "feature", glue = "stepdef", dryRun = false, monochrome = true, format = {
		"junit:test-output/cucumber.xml", "json:test-output/cucumber.json" })
public class TestRunner {

}