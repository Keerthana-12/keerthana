package stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class Booking {

	@FindBy(name = "userName")
	WebElement userName;
	@FindBy(name = "userPwd")
	WebElement password;
	@FindBy(xpath = "//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input\r\n")
	WebElement login;

	@FindBy(id = "txtFirstName")
	WebElement firstname;

	@FindBy(id = "txtLastName")
	WebElement lastname;

	@FindBy(id = "txtEmail")
	WebElement email;

	@FindBy(id = "txtPhone")
	WebElement phoneno;

	@FindBy(xpath = "/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
	WebElement address;

	@FindBy(name = "city")
	WebElement city;

	@FindBy(name = "state")
	WebElement state;

	@FindBy(name = "persons")
	WebElement persons;

	@FindBy(id = "txtCardholderName")
	WebElement holdername;

	@FindBy(name = "debit")
	WebElement debit;

	@FindBy(name = "cvv")
	WebElement cvv;

	@FindBy(name = "month")
	WebElement month;

	@FindBy(name = "year")
	WebElement year;

	@FindBy(id = "btnPayment")
	WebElement confirmBtn;

	public Booking(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public void entersLoginCredentials() {
		userName.sendKeys("capgemini");
		password.sendKeys("capg1234");

	}

	public void clicksSubmit() {
		login.click();

	}

	public void enterDetails() {
		firstname.sendKeys("prakash");
		lastname.sendKeys("sai");
		email.sendKeys("abc@gmail.com");
		phoneno.sendKeys("8758789767");
		address.sendKeys("M.I.P.L");
		city.sendKeys("Chennai");
		state.sendKeys("Tamilnadu");
		persons.sendKeys("3");
		holdername.sendKeys("Prakash");
		debit.sendKeys("8090909089897676");
		cvv.sendKeys("206");
		month.sendKeys("05");
		year.sendKeys("2038");

	}

	public void confirmBooking() {
		confirmBtn.click();
	}

}
