package stepdef;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;

import com.google.common.base.Verify;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.*;

public class BookingSteps {
	WebDriver driver;
	Booking booking;

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KANTPRAK\\JEE Full stack\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		booking = new Booking(driver);
	}

	@Given("^user enter into login page$")
	public void user_enter_into_login_page() throws Throwable {
		driver.get("file:///C:/Users/KANTPRAK/JEE%20Full%20stack/Module%204/hotelBooking/login.html");
		driver.findElement(By.xpath("//*[@id='mainCnt']/div/div[1]/h1"));

	}

	@When("^user enter the username and password$")
	public void user_enter_the_username_and_password() throws Throwable {
		booking.entersLoginCredentials();

	}

	@When("^click submit$")
	public void click_submit() throws Throwable {
		booking.clicksSubmit();
	}

	@When("^able to reach hotel booking form$")
	public void able_to_reach_hotel_booking_form() throws Throwable {
		Assert.assertEquals(driver.getTitle(), "Hotel Booking");

	}

	@When("^user enters details$")
	public void user_enters_details() throws Throwable {
		booking.enterDetails();
	}

	@When("^click confirm booking$")
	public void click_confirm_booking() throws Throwable {
		
		booking.confirmBooking();
	}

	@Then("^user able book the hotel successfully$")
	public void user_able_book_the_hotel_successfully() throws Throwable {
		Assert.assertEquals(driver.getTitle(), "Payment Details");

	}

//	@After
//	public void quit() {
//		//driver.close();
//	}
}