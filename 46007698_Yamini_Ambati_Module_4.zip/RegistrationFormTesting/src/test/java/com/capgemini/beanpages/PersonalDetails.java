package com.capgemini.beanpages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
/*
 * This is a java class called PersonalDetails used to locate the UI elements of the 
 * HTML form "PersonalDetails.html"
 */
public class PersonalDetails {
	
	WebDriver driver;
	
	public PersonalDetails(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name="txtFN")
	WebElement firstName;
	
	@FindBy(name="txtLN")
	WebElement lastName;
	
	@FindBy(name="Email")
	WebElement email;	
	
	@FindBy(name="Phone")
	WebElement contact;	
	
	@FindBy(name="address1")
	WebElement address1;	
	
	@FindBy(name="address2")
	WebElement address2;	
	
	@FindBy(name="city")
	WebElement city;	
	
	@FindBy(name="state")
	WebElement state;	
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[11]/td/a")
	WebElement next;	
	
	
	public WebElement firstName() {
		return firstName;
	}
	
	public WebElement lastName() {
		return lastName;
	}
	
	public WebElement email() {
		return email;
	}
	
	public WebElement contact() {
		return contact;
	}
	
	public WebElement address1() {
		return address1;
	}
	
	public WebElement address2() {
		return address2;
	}
	
	public WebElement city() {
		return city;
	}
	
	public WebElement state() {
		return state;
	}
	
	public WebElement next() {
		return next;
	}
	
}
