package com.capgemini.beanpages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/*
 * This is a java class called EducationDetails used to locate the UI elements of the 
 * HTML form "EducationalDetails.html"
 */
public class EducationalDetails {
	
	WebDriver driver;
	
	public EducationalDetails(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="/html/body/h4")
	WebElement header;
	
	@FindBy(name="graduation")
	WebElement graduation;
	
	@FindBy(name="percentage")
	WebElement percentage;
	
	@FindBy(name="passingYear")
	WebElement passingYear;
	
	@FindBy(name="projectName")
	WebElement projectName;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[1]")
	WebElement net;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[2]")
	WebElement java;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[3]")
	WebElement php;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[4]")
	WebElement other;
	
	@FindBy(name="otherTechnologies")
	WebElement otherTechnologies;
	
	@FindBy(xpath="//*[@id=\"btnRegister\"]")
	WebElement registerMe;
	
	public WebElement header() {
		return header;
	}
	
	public WebElement graduation() {
		return graduation;
	}
	
	public WebElement percentage() {
		return percentage;
	}
	
	public WebElement passingYear() {
		return passingYear;
	}
	
	public WebElement projectName() {
		return projectName;
	}
	
	public WebElement net() {
		return net;
	}
	
	public WebElement java() {
		return java;
	}
	
	public WebElement php() {
		return php;
	}
	
	public WebElement other() {
		return other;
	}
	
	public WebElement otherTechnologies() {
		return otherTechnologies;
	}
	
	public WebElement registerMe() {
		return registerMe;
	}
	
}
