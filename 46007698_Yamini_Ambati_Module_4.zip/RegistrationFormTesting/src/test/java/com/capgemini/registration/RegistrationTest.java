package com.capgemini.registration;

import org.junit.runner.RunWith;

import cucumber.api.junit.Cucumber;
/*
 * This is the runner class for this application.
 * Cucumber test runner class is a
 * mechanisms using which you can run Cucumber feature file.
 */
@RunWith(Cucumber.class)
public class RegistrationTest {

}
