package com.capgemini.registration;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.capgemini.beanpages.EducationalDetails;
import com.capgemini.beanpages.PersonalDetails;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
/*
 * This is a java file called "RegistrationSteps.java" used to create an instance for
 * the WebDriver, PersonalDetails and EducationDetails and fill the data in 
 * the form.  
 */
public class RegistrationSteps {
	
	WebDriver driver;
	PersonalDetails personalDetails;
	EducationalDetails educationalDetails;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\YAAMBATI\\chromedriver.exe");
		driver = new ChromeDriver();
		personalDetails = new PersonalDetails(driver);
		educationalDetails = new EducationalDetails(driver);
	}
	
	@Given("^User is on Personal details Form page$")
	public void user_is_on_Personal_details_Form_page() throws Throwable {
		driver.get("C:\\Users\\YAAMBATI\\Desktop\\SET B\\PersonalDetails.html");
		driver.manage().window().maximize();
	}

	@Then("^Title should be 'Personal Details'$")
	public void title_should_be_Personal_Details() throws Throwable {
		assertEquals("Personal Details", driver.getTitle());
	}

	@When("^Next button is clicked without entering First Name$")
	public void next_button_is_clicked_without_entering_First_Name() throws Throwable {
		personalDetails.next().click();
		Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please fill the First Name'$")
	public void alert_message_should_be_displayed_as_Please_fill_the_First_Name() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill the First Name", alert.getText());
		alert.accept();
	}

	@When("^Next button is clicked without entering Last Name$")
	public void next_button_is_clicked_without_entering_Last_Name() throws Throwable {
		personalDetails.firstName().sendKeys("Yamini");
		personalDetails.next().click();
		Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please fill the Last Name'$")
	public void alert_message_should_be_displayed_as_Please_fill_the_Last_Name() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill the Last Name", alert.getText());
		alert.accept();
	}

	@When("^Next button is clicked without entering Email$")
	public void next_button_is_clicked_without_entering_Email() throws Throwable {
		personalDetails.lastName().sendKeys("Ambati");
		personalDetails.next().click();
		Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please fill the Email'$")
	public void alert_message_should_be_displayed_as_Please_fill_the_Email() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill the Email", alert.getText());
		alert.accept();
	}

	@When("^Next button is clicked without entering valid Email$")
	public void next_button_is_clicked_without_entering_valid_Email() throws Throwable {
		personalDetails.email().sendKeys("yamini@com");
		personalDetails.next().click();
		Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please enter valid Email Id\\.'$")
	public void alert_message_should_be_displayed_as_Please_enter_valid_Email_Id() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please enter valid Email Id.", alert.getText());
		alert.accept();
	}

	@When("^Next button is clicked without entering Contact Number$")
	public void next_button_is_clicked_without_entering_Contact_Number() throws Throwable {
		personalDetails.email().clear();
		personalDetails.email().sendKeys("yaminiambati09@gmail.com");
		personalDetails.next().click();
		Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please fill the Contact No\\.'$")
	public void alert_message_should_be_displayed_as_Please_fill_the_Contact_No() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill the Contact No.", alert.getText());
		alert.accept();
	}

	@When("^Next button is clicked without entering Valid Contact Number$")
	public void next_button_is_clicked_without_entering_Valid_Contact_Number() throws Throwable {
		personalDetails.contact().sendKeys("9996123");
		personalDetails.next().click();
		Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please enter valid Contact no\\.'$")
	public void alert_message_should_be_displayed_as_Please_enter_valid_Contact_no() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please enter valid Contact no.", alert.getText());
		alert.accept();
	}
	
	@When("^Next button is clicked without entering Address Line (\\d+)$")
	public void next_button_is_clicked_without_entering_Address_Line(int arg1) throws Throwable {
		personalDetails.contact().clear();
		personalDetails.contact().sendKeys("8125960502");
		personalDetails.next().click();
		Thread.sleep(1000);
	}

	@Then("^alert message for address line should be displayed as 'Please fill the address line(\\d+)'$")
	public void alert_message_for_address_line_should_be_displayed_as_Please_fill_the_address_line(int arg1) throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill the address line "+arg1, alert.getText());
		alert.accept();
	}

	@When("^Next button is clicked without entering Valid Address Line (\\d+)$")
	public void next_button_is_clicked_without_entering_Valid_Address_Line(int arg1) throws Throwable {
		personalDetails.address1().sendKeys("S.R. nagar");
		personalDetails.next().click();
		Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please fill the address line(\\d+)'$")
	public void alert_message_should_be_displayed_as_Please_fill_the_address_line(int arg1) throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill the address line "+arg1, alert.getText());
		alert.accept();
	}

	@When("^Next button is clicked without selecting City$")
	public void next_button_is_clicked_without_selecting_City() throws Throwable {
		personalDetails.address2().sendKeys("Kukatpally");
		personalDetails.next().click();
		Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please select city'$")
	public void alert_message_should_be_displayed_as_Please_select_city() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please select city", alert.getText());
		alert.accept();
	}

	@When("^Next button is clicked without selecting State$")
	public void next_button_is_clicked_without_selecting_State() throws Throwable {
		Select selectCity=new Select(personalDetails.city());
		selectCity.selectByVisibleText("Hyderabad");
		personalDetails.next().click();
		Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please select state'$")
	public void alert_message_should_be_displayed_as_Please_select_state() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please select state", alert.getText());
		alert.accept();
	}

	@When("^Next button is clicked after entering valid details$")
	public void next_button_is_clicked_after_entering_valid_details() throws Throwable {
		Select selectState=new Select(personalDetails.state());
		selectState.selectByVisibleText("Telangana");
		personalDetails.next().click();
		Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Personal details are validated and accepted successfully\\.'$")
	public void alert_message_should_be_displayed_as_Personal_details_are_validated_and_accepted_successfully() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Personal details are validated and accepted successfully.", alert.getText());
		alert.accept();
	}
	
	@Given("^User is on Educational details Form page$")
	public void user_is_on_Educational_details_Form_page() throws Throwable {
		 // driver.switchTo().window(personalDetails.get(0));
	}

	@Then("^Title should be 'Educational Details'$")
	public void title_should_be_Educational_Details() throws Throwable {
	    assertEquals("Educational Details", driver.getTitle() );
	}

	@Then("^Headline should be visible as 'Step (\\d+): Educational Details'$")
	public void headline_should_be_visible_as_Step_Educational_Details(int arg1) throws Throwable {
	    assertEquals("Step "+arg1+": Educational Details", educationalDetails.header().getText());
	}

	@When("^Register Me button is clicked without selecting graduation$")
	public void register_Me_button_is_clicked_without_selecting_graduation() throws Throwable {
		educationalDetails.registerMe().click();
		Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please Select Graduation'$")
	public void alert_message_should_be_displayed_as_Please_Select_Graduation() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please Select Graduation", alert.getText());
		alert.accept();
	}

	@When("^Register Me button is clicked without entering percenatge$")
	public void register_Me_button_is_clicked_without_entering_percenatge() throws Throwable {
		Select selectGraduation=new Select(educationalDetails.graduation());
		selectGraduation.selectByVisibleText("BTech");
		educationalDetails.registerMe().click();
		Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please fill Percentage detail'$")
	public void alert_message_should_be_displayed_as_Please_fill_Percentage_detail() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill Percentage detail", alert.getText());
		alert.accept();
	}

	@When("^Register Me button is clicked without entering passing year$")
	public void register_Me_button_is_clicked_without_entering_passing_year() throws Throwable {
	    educationalDetails.percentage().sendKeys("76%");
	    educationalDetails.registerMe().click();
	    Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please fill Passing Year'$")
	public void alert_message_should_be_displayed_as_Please_fill_Passing_Year() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill Passing Year", alert.getText());
		alert.accept();
	}

	@When("^Register Me button is clicked without entering project name$")
	public void register_Me_button_is_clicked_without_entering_project_name() throws Throwable {
		educationalDetails.passingYear().sendKeys("2019");
	    educationalDetails.registerMe().click();
	    Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please fill Project Name'$")
	public void alert_message_should_be_displayed_as_Please_fill_Project_Name() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill Project Name", alert.getText());
		alert.accept();
	}

	@When("^Register Me button is clicked without Selecting technologies$")
	public void register_Me_button_is_clicked_without_Selecting_technologies() throws Throwable {
		educationalDetails.projectName().sendKeys("Action Recognition");
	    educationalDetails.registerMe().click();
	    Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please Select Technologies Used'$")
	public void alert_message_should_be_displayed_as_Please_Select_Technologies_Used() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please Select Technologies Used", alert.getText());
		alert.accept();
	}

	@When("^others box is selected and Register Me button is clicked without entering other technologies$")
	public void others_box_is_selected_and_Register_Me_button_is_clicked_without_entering_other_technologies() throws Throwable {
	    educationalDetails.net().click();
	    educationalDetails.other().click();
	    educationalDetails.registerMe().click();
	    Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Please fill other Technologies Used'$")
	public void alert_message_should_be_displayed_as_Please_fill_other_Technologies_Used() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill other Technologies Used", alert.getText());
		alert.accept();
	}

	@When("^Register Me button is clicked after entering all the correct details$")
	public void register_Me_button_is_clicked_after_entering_all_the_correct_details() throws Throwable {
	   educationalDetails.otherTechnologies().sendKeys("Computer Vision");
	   educationalDetails.registerMe().click();
	   Thread.sleep(1000);
	}

	@Then("^alert message should be displayed as 'Your Registration Has succesfully done Plz check you registerd email for account activation link !!!'$")
	public void alert_message_should_be_displayed_as_Your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Your Registration Has succesfully done Plz check you registerd email for account activation link !!!", alert.getText());
		alert.accept();
		driver.close();
	}
}
