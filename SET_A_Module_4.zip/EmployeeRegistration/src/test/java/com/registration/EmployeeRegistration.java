package com.registration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EmployeeRegistration {

	WebDriver driver;

	public EmployeeRegistration(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name="B4")
	WebElement submit;
	
	@FindBy(name="emp_name")
	WebElement empname;
	
	@FindBy(name="num")
	WebElement empnumber;
	
	@FindBy(name="txtFName1")
	WebElement contactnumber;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/select/option[2]")
	WebElement location;
		
	@FindBy(name="email_id")
	WebElement email;
	

	
	public WebElement submit()
	{
		return submit;	
	}
	
	
	public WebElement empname()
	{
		return empname;
	}
	
	
	public WebElement empnumber()
	{
		return empnumber;
	}
	
	public WebElement email()
	{
		return email;
	}
	public WebElement contactnumber()
	{
		return contactnumber;
	}
	public WebElement location()
	{
		return location;
	}
	
	
	
}
