package com.registration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Home {
   
	WebDriver driver;

	public Home(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	@FindBy(linkText="Register")
	WebElement register;
	
	@FindBy(linkText="Contact Us")
	WebElement contact;
	
	@FindBy(className="primary-content")
	WebElement homecontent;
	
	public WebElement homecontent()
	{
		return homecontent;
	}
	
	public WebElement register()
	{
		return register;
	}
	
	
	public WebElement contact()
	{
		return contact;
	}
	
}
