package com.steps;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.registration.ContactUs;
import com.registration.EmployeeRegistration;
import com.registration.Home;
import com.registration.Success;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	WebDriver driver;
	Home home;
	ContactUs contactus;
	EmployeeRegistration employeeregistration;
	Success success;
	
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\YAAMBATI\\chromedriver.exe");
		driver=new ChromeDriver();
		home=new Home(driver);
		contactus=new ContactUs(driver);
		employeeregistration=new EmployeeRegistration(driver);
		success=new Success(driver);
	}

	@Given("^User is on Home page$")
	public void user_is_on_Home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.get("C:\\Users\\YAAMBATI\\Desktop\\SET03\\WebPages\\PersonalDetails.html");
	}
	@Then("^the header content should be Welcome to our Page$")
	public void the_header_content_should_be_Welcome_to_our_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    assertEquals("Welcome to our Page",home.homecontent().getText());
	}




	@When("^user clicks on Contact Us link$")
	public void user_clicks_on_Contact_Us_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   home.contact().click();
	   
	}

	@Then("^Title should be Infoway Tech India$")
	public void title_should_be_Infoway_Tech_India() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   assertEquals("Infoway Tech India", contactus.title().getText());
	   driver.get("C:\\\\Users\\YAAMBATI\\Desktop\\SET03\\\\WebPages\\PersonalDetails.html");
	}


	@When("^user clicks on Registration link$")
	public void user_clicks_on_Registration_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    home.register().click();
	}
	
	@Then("^Title should be User Registration Page$")
	public void title_should_be_User_Registration_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 assertEquals(driver.getTitle(),"Employee Registration Page");
	}


	@When("^Submit button is clicked without entering any value$")
	public void submit_button_is_clicked_without_entering_any_value() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   employeeregistration.submit().click();
	}

	@Then("^alert box should be displayed as 'Please fill in the 'Your Employee Name' box\\.'$")
	public void alert_box_should_be_displayed_as_Please_fill_in_the_Your_Employee_Name_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Please fill in the 'Your Employee Name' box.", alert.getText());
	   alert.accept();
	}

	@When("^Submit button is clicked without entering any Employee Number$")
	public void submit_button_is_clicked_without_entering_any_Employee_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    employeeregistration.empname().sendKeys("Radhika");
		employeeregistration.submit().click();
	}

	@Then("^alert box should be displayed as 'Enter Employee Number'$")
	public void alert_box_should_be_displayed_as_Enter_Employee_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Enter Employee Number", alert.getText());
	   alert.accept();
	}

	@When("^user enters any character in Employee Number$")
	public void user_enters_any_character_in_Employee_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   employeeregistration.empnumber().sendKeys("a");
	}

	@Then("^alert box should be displayed as 'Enter Number'$")
	public void alert_box_should_be_displayed_as_Enter_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Enter Number", alert.getText());
	   alert.accept();
	}

	
	@When("^user enter any character in a Contact Number$")
	public void user_enter_any_character_in_a_Contact_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		employeeregistration.empnumber().clear();
		employeeregistration.empnumber().sendKeys("4524");
	   employeeregistration.contactnumber().sendKeys("a");
	}
	
	@Then("^alert box should  display 'Enter Number'$")
	public void alert_box_should_display_Enter_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Enter Number", alert.getText());
	   alert.accept();

	}


	@When("^Submit button is clicked without selecting any Job Location$")
	public void submit_button_is_clicked_without_selecting_any_Job_Location() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    employeeregistration.contactnumber().clear();
	    employeeregistration.contactnumber().sendKeys("9874563210");
	    employeeregistration.submit().click();
	    
	}

	@Then("^alert box should be displayed as 'Select your Job Location'$")
	public void alert_box_should_be_displayed_as_Select_your_Job_Location() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("Select your Job Location", alert.getText());
	   alert.accept();
	}

	@When("^user clicks submit button on entering wrong email pattern$")
	public void user_clicks_submit_button_on_entering_wrong_email_pattern() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   employeeregistration.location().click();
	   employeeregistration.email().sendKeys("Java");
	   employeeregistration.submit().click();
	   
	}

	@Then("^alert box should be displayed as 'You have entered an invalid email address!'$")
	public void alert_box_should_be_displayed_as_You_have_entered_an_invalid_email_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert=driver.switchTo().alert();
		assertEquals("You have entered an invalid email address!", alert.getText());
	   alert.accept();
	}

	@When("^user clicks submit button$")
	public void user_clicks_submit_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   employeeregistration.email().clear();
	   employeeregistration.email().sendKeys("radhika@gmail.com");
	   employeeregistration.submit().click();
	}

	@Then("^new page should be displayeed with the message 'Registered Successfully!'$")
	public void new_page_should_be_displayeed_with_the_message_Registered_Successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  assertEquals("Registered Successfully!", success.titlecheck().getText());
	
	}
	

	
}
