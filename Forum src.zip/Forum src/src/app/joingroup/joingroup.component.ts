import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { ForumService } from '../forum.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-joingroup',
  templateUrl: './joingroup.component.html',
  styleUrls: ['./joingroup.component.css']
})
export class JoingroupComponent implements OnInit {
member:User;
  constructor(private forumService:ForumService,private router:Router) { 
    this.member=new User();
  }

  ngOnInit() {
  }
  joinGroup(memberName,dob,adminName):void {
    if(memberName==""||dob==""||adminName==""){
      alert("Please fill out the empty field")
       }
      else{
    this.member.memberName=memberName;
    this.member.dob=dob;
    this.member.adminName=adminName; 
    this.forumService.joinGroup(this.member).subscribe(data => {
      alert("Added you!!")
      this.router.navigate(['/memberlist'])
    });
}}
}
