import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from './user';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ForumService {

  constructor(private httpClient:HttpClient) { }

  public addGroup(groupDetails) {

    return this.httpClient.post<User>("http://localhost:9099/creategroup", groupDetails);
    }

    public addTopic(topicDetails) {
    
      return this.httpClient.post<User>("http://localhost:9099/addtopic", topicDetails);
      }

      public postComment(commentDetails) {
    
        return this.httpClient.post<User>("http://localhost:9099/postcomment", commentDetails);
        }
        public getAllGroupDetails()
        {
          return this.httpClient.get<User>("http://localhost:9099/viewalldetails");
        }
        public getAllTopicDetails()
        {
          return this.httpClient.get<User>("http://localhost:9099/viewalltopics");
        }
        public postedComments()
        {
          return this.httpClient.get<User>("http://localhost:9099/postedcomments");
        }
        public joinGroup(joinGroupDetails) {

          return this.httpClient.post<User>("http://localhost:9099/postrequest", joinGroupDetails);
          }
          public getAllMembers()
        {
          return this.httpClient.get<User>("http://localhost:9099/getallrequest");
        }
        public removeMember(memberId)
        {
          return this.httpClient.delete<User>("http://localhost:9099/removemember/"+memberId);
        }
        public validateMember(memberName):Observable<boolean>
        {
          return this.httpClient.get<boolean>("http://localhost:9099/validatemember/"+memberName);
        }
        public validateTopic(topicName):Observable<boolean>
        {
          return this.httpClient.get<boolean>("http://localhost:9099/validatetopic/"+topicName);
        }
}
