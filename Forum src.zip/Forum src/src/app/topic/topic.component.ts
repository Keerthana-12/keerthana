import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { ForumService } from '../forum.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-topic',
  templateUrl: './topic.component.html',
  styleUrls: ['./topic.component.css']
})
export class TopicComponent implements OnInit {
  member:User;
  constructor(private forumService:ForumService,private router:Router) {
    this.member=new User();
   }

  ngOnInit() {
  }
  addTopic(topicName,groupId):void {
    if(topicName==""||groupId==""){
      alert("Please fill out the empty field")
       }
      else{
    this.member.topicName=topicName;
    this.member.groupId=groupId; 
    this.forumService.addTopic(this.member).subscribe(data => {
      this.router.navigate(['/topiclist'])
    });
}}
}
