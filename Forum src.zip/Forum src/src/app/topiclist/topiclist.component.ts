import { Component, OnInit } from '@angular/core';
import { ForumService } from '../forum.service';

@Component({
  selector: 'app-topiclist',
  templateUrl: './topiclist.component.html',
  styleUrls: ['./topiclist.component.css']
})
export class TopiclistComponent implements OnInit {
topics;
  constructor(private forumService:ForumService) { 
    forumService.getAllTopicDetails().subscribe((res) => this.topics=res)
  }
  
  ngOnInit() {
  }

}
