import { Component, OnInit } from '@angular/core';
import { ForumService } from '../forum.service';

@Component({
  selector: 'app-groupmembers',
  templateUrl: './groupmembers.component.html',
  styleUrls: ['./groupmembers.component.css']
})
export class GroupmembersComponent implements OnInit {
members;
  constructor(private forumService:ForumService) {
    forumService.getAllMembers().subscribe((res) => this.members=res)
   }

  ngOnInit() {
  }
  removeMember(memberId){
    this.forumService.removeMember(memberId).subscribe(()=>{
      alert('You are removed from this group')
      history.go();
    })
  }
}
