import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { ForumService } from '../forum.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {
member:User;
  constructor(private forumService:ForumService,private router:Router) {
    this.member=new User();
   }

  ngOnInit() {
  }
  postComment(commentText,memberName,topicName):void {
    if(commentText==""||memberName==""||topicName==""){
      alert("Please fill out the empty field")
       }
      else {
        if( this.forumService.validateMember(memberName).subscribe(data => {
          
          if(data==false){
            alert("Invalid Member")
          }

          else {
            this.member.commentText=commentText; 
            this.member.memberName=memberName;
            this.member.topicName=topicName;
           
            this.forumService.postComment(this.member).subscribe(data => {
              this.router.navigate(['/postedcomments'])
            });
        }
          
        })){}
        
      }

}
}
