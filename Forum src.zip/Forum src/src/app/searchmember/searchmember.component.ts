import { Component, OnInit } from '@angular/core';
import { ForumService } from '../forum.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-searchmember',
  templateUrl: './searchmember.component.html',
  styleUrls: ['./searchmember.component.css']
})
export class SearchmemberComponent implements OnInit {

  constructor(private forumService:ForumService,private router:Router) { }

  ngOnInit() {
  }
  search;
b;
member;
  searchMember(search)
 {
  this.forumService.validateMember(this.search).subscribe(data => {
          
    if(data==true){
      this.b=search
 this.forumService.getAllMembers().subscribe((res)=>this.member=res)
    }
  
    else
    {
 alert("Invalid Member");
 }

  });
}
}
