import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '../../../node_modules/@angular/router';
 
@Component({
 selector: 'app-search',
 templateUrl: './search.component.html',
 styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
 
 constructor(private ps:ProductService,private router:Router) { }
 
 ngOnInit() {
 }
 
 search;
 b;
 product;
 searchProduct(search)
 {
 this.b=search
 this.ps.getAll().subscribe((res)=>this.product=res)
 }
 
}