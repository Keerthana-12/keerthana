import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  constructor(private ps:ProductService, private router:Router) { }

    product = {
      name:'',
      price:''
    }
  
    addProduct(){
      this.ps.add(this.product).subscribe(()=>{
        alert('added...!')
        this.router.navigate([''])})
    }

  ngOnInit() {
  }

}
