import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {

  emp;
  constructor(private e:EmployeeService) { 
  e.getAll().subscribe((res) => this.emp=res)
  }
  removeMobile(id){
  this.e.remove(id).subscribe(()=>{
  alert('deleted...')
  history.go(); 
  })
 }
  ngOnInit() {
  }

}
