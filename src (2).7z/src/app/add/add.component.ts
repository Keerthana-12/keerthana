import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  emp={
    id:'',
    name:'',
    project:'',
    manager:''
  }
  constructor(private e:EmployeeService,private router:Router) { }
  addEmp(){
    this.e.add(this.emp).subscribe(()=>{
      alert('added')

    })
  }
  ngOnInit() {
  }

}
