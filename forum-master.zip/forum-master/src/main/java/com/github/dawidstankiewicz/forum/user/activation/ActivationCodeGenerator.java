package com.github.dawidstankiewicz.forum.user.activation;

public interface ActivationCodeGenerator {

    String generate();

}
