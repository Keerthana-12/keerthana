package com.github.dawidstankiewicz.forum.user;

public interface UserCreationService {

    void create(User user);
}
