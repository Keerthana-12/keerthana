package com.github.dawidstankiewicz.forum.user.activation;

public interface ActivationService {

    void activate(String username, String id);
}
