package com.cg.bankapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.bankapp.bean.TransactionDetails;



public interface ITransactionDao extends JpaRepository <TransactionDetails,Long> 
{
	//@Query("from TransactionDetails where AccountNumber = :accn")
	//List<TransactionDetails> findById(@Param("accn") long acc);

	//static List<TransactionDetails> printTransaction(long accno) {
	//return null;
	//}
}