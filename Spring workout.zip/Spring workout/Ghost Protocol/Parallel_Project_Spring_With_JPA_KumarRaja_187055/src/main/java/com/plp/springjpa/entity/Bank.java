package com.plp.springjpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="SpringBank")
public class Bank 
{
	@Column(name="ename")
	private String name;
	
	
	@Id
	@Column(name="eAcc",length=20)
	private long accountNo;
	
	@Column(name="epass",length=20)
	private String password;
	
	@Column(name="ephone", length=20)
	private String phoneNo;
	
	@Column(name="ebal" , length=20)
	private int balance;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "BankBean [name=" + name + ", accountNo=" + accountNo + ", password=" + password + ", phoneNo=" + phoneNo
				+ ", balance=" + balance + "]";
	}
	
	
	
}
	
