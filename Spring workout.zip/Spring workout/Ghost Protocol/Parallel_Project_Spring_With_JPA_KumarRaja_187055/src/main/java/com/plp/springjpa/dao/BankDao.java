package com.plp.springjpa.dao;

import java.util.List;

import com.plp.springjpa.entity.Bank;
import com.plp.springjpa.entity.Transaction;

public interface BankDao {
   boolean createAccount(Bank bank);
   int showBalance(long accountNo);
   int depositBalance(long accountNo, int deposit);
   int withdrawAmount(long accountNo, int withdraw) ;
   boolean fundTransfer(long accountNo, long accno, int amount);
   boolean validateAccount(long accountNo,String password);
	public List<Transaction> getTransactions(long accountNo) ;
	


}
