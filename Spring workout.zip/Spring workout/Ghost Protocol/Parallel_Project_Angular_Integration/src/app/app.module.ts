import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateComponent } from './create/create.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { CashTransferComponent } from './cash-transfer/cash-transfer.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { ViewComponent } from './view/view.component';
import {HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    CreateComponent,
    DepositComponent,
    WithdrawComponent,
    ShowBalanceComponent,
    CashTransferComponent,
    TransactionsComponent,
    ViewComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
