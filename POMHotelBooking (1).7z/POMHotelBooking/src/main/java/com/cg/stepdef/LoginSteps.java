package com.cg.stepdef;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class LoginSteps {
	WebDriver driver;
	LoginPage login;

	@Given("^user is on Html Login page$")
	public void user_is_on_Html_Login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\THENMOM\\Selenium driver\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("C:\\Users\\THENMOM\\SeleniumBDD\\POMHotelBooking\\src\\main\\resources\\login.html");
		login = new LoginPage(driver);
		
	}
	
	@When("^user entering \"([^\"]*)\" and \"([^\"]*)\" and login$")
	public void user_entering_and_and_login(String username, String password) throws Throwable {
		login.userName.sendKeys(username);
		login.password.sendKeys(password);
		login.clickLogin();
		Thread.sleep(1000);
		driver.quit();
	}

	/*@When("^login is clicked without entering the Firstname$")
	public void login_is_clicked_without_entering_the_Firstname() throws Throwable {
		login.passwordDetail();
		login.clickLogin();
		Thread.sleep(1000);
		driver.quit();
		
	}

	@When("^login is clicked without entering the password$")
	public void login_is_clicked_without_entering_the_password() throws Throwable {
		login.usernameDetail();
		login.clickLogin();
		Thread.sleep(1000);
		driver.quit();
		
	}*/
	

	@When("^user enters \"([^\"]*)\" and \"([^\"]*)\" and login$")
	public void user_enters_and_and_login(String username, String password) throws Throwable {
		login.userName.sendKeys(username);
		login.password.sendKeys(password);
		login.clickLogin();
		
	}

	@Then("^verify the title of the page$")
	public void verify_the_title_of_the_page() throws Throwable {
		Assert.assertEquals("Hotel Booking", driver.getTitle());
	}

	@When("^user enters the \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_the_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6,
			String arg7, String arg8, String arg9, String arg10, String arg11, String arg12) throws Throwable {
		login.firstName.sendKeys(arg1);

		login.lastName.sendKeys(arg2);

		login.email.sendKeys(arg3);

		login.mobNo.sendKeys(arg4);

		login.address.sendKeys(arg5);

		login.city.sendKeys(arg6);

		login.state.sendKeys(arg7);
		
		login.holderName.sendKeys(arg8);
		
		login.cardNumber.sendKeys(arg9);
		
		login.cvv.sendKeys(arg10);
		
		login.expMonth.sendKeys(arg11);
		
		login.expYear.sendKeys(arg12);
	}

	@When("^user clicks on Confirm Booking$")
	public void user_clicks_on_Confirm_Booking() throws Throwable {
		login.bookingLogin();
		Thread.sleep(1000);
		 driver.switchTo().alert().accept();
		 driver.quit();
        }
	@When("^user enters correct credentials$")
	public void user_enters_correct_credentials() throws Throwable {
		login.firstName.sendKeys("Thenmozhi");

		login.lastName.sendKeys("Murali");

		login.email.sendKeys("m.thenmozhi@gmail.com");

		login.mobNo.sendKeys("9963321547");

		login.address.sendKeys("No.4/144\nKamarajar Salai\nManjambakkam\nChennai");

		login.city.sendKeys("Chennai");

		login.state.sendKeys("Tamilnadu");
		
		login.holderName.sendKeys("Thenmozhi");
		
		login.cardNumber.sendKeys("123425631");
		
		login.cvv.sendKeys("963");
		
		login.expMonth.sendKeys("03");
		
		login.expYear.sendKeys("2020");
	}

	@When("^user is clicking Confirm Booking$")
	public void user_is_clicking_Confirm_Booking() throws Throwable {
		login.bookingLogin();
		Thread.sleep(1000);
	}

	@Then("^Successfully booked page is reached$")
	public void successfully_booked_page_is_reached() throws Throwable {
		Assert.assertEquals("Payment Details", driver.getTitle());
		 driver.quit();
	}

}
