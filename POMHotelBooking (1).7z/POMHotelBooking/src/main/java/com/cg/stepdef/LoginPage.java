package com.cg.stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
	@FindBy(name="userName")
	WebElement userName;
	
	@FindBy(name="userPwd")
	WebElement password;
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
	WebElement clickLogin;
	
	@FindBy(id="btnPayment")
	WebElement confirmBooking;
	
	@FindBy(id="txtFirstName")
	WebElement firstName;
	
	@FindBy(id="txtLastName")
	WebElement lastName;
	
	
	@FindBy(id="txtEmail")
	WebElement email;
	
	@FindBy(id="txtPhone")
	WebElement mobNo;
	
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
	WebElement address;
	
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[7]/td[2]/select")
	WebElement city;
	
	@FindBy(name="state")
	WebElement state;
	
	@FindBy(id="txtCardholderName")
	WebElement holderName;
	
	@FindBy(id="txtDebit")
	WebElement cardNumber;
	
	@FindBy(id="txtCvv")
	WebElement cvv;
	
	@FindBy(id="txtMonth")
	WebElement expMonth;
	
	@FindBy(id="txtYear")
	WebElement expYear;
	
public LoginPage(WebDriver driver) {
	PageFactory.initElements(driver, this);

}
public void emptyUsernameDetail() {
	userName.sendKeys("");
}

public void usernameDetail() {
	userName.sendKeys("Thenmozhi");
}

public void emptyPasswordDetail() {
	password.sendKeys("");
}

public void passwordDetail() {
	password.sendKeys("12Th2");
}
public void bookingLogin() {
	confirmBooking.click();
}
public void clickLogin(){
	clickLogin.click();
}
}
