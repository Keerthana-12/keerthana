package com.cg.forum.daos;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.forum.beans.RequestStatus;
import com.cg.forum.exceptions.ForumException;

public interface IGroupRequestDao extends JpaRepository<RequestStatus,Integer>{
   @Query(value="select request_status from request_status where member_name=?1",nativeQuery=true)
   public String getRequestStatusById(String member_name);
}
