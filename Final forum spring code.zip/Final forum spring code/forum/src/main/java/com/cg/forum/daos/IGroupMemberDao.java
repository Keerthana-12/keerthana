package com.cg.forum.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.forum.beans.GroupMembers;

public interface IGroupMemberDao extends JpaRepository<GroupMembers,Integer>{
	@Query(value="select * from group_members where member_name=?1", nativeQuery=true)
    public GroupMembers validateMember(String memberName);
}
