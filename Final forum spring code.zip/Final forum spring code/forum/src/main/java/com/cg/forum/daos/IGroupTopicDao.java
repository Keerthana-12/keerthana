package com.cg.forum.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.forum.beans.GroupsTopic;

public interface IGroupTopicDao extends JpaRepository<GroupsTopic,Integer> {
	@Query(value="select * from groups_topic where topic_name=?1", nativeQuery=true)
    public GroupsTopic validateTopic(String topicName);
}
