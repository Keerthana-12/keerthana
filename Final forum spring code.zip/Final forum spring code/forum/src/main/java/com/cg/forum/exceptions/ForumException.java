package com.cg.forum.exceptions;

public class ForumException extends Exception{
    public ForumException()
    {
    	super();
    }
    public ForumException(String str)
    {
    	super(str);
    }
}
