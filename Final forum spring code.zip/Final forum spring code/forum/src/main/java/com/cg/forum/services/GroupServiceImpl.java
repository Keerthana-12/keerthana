package com.cg.forum.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.forum.beans.Admin;
import com.cg.forum.beans.GroupComment;
import com.cg.forum.beans.GroupMembers;
import com.cg.forum.beans.Groups;
import com.cg.forum.beans.GroupsTopic;
import com.cg.forum.beans.RequestStatus;
import com.cg.forum.daos.IGroupAdminDao;
import com.cg.forum.daos.IGroupCommentDao;
import com.cg.forum.daos.IGroupMemberDao;
import com.cg.forum.daos.IGroupRequestDao;
import com.cg.forum.daos.IGroupTopicDao;
import com.cg.forum.daos.IGroupsDao;
import com.cg.forum.exceptions.ForumException;
@Service
public class GroupServiceImpl implements IGroupService{
	@Autowired
	IGroupsDao groupsDao;
	
	@Autowired
	IGroupTopicDao topicDao;
	@Autowired
	IGroupMemberDao memberDao;
	@Autowired
	IGroupCommentDao commentDao;
	@Autowired
	IGroupAdminDao adminDao;
	@Autowired
	IGroupRequestDao requestDao;
	
	public Groups createGroup(Groups groups){
		
		return groupsDao.save(groups);
		
	}
	
	public Groups getGroupById(int groupId) throws ForumException{
		try
		{
		return groupsDao.findById(groupId).get();
		}
		catch(Exception ex)
		{
			throw new ForumException("Oops!! Invalid group Id.");
		}
	}
	public List<Groups> viewAllGroups()
	{
		return groupsDao.findAll();
	}
	public GroupsTopic addTopic(GroupsTopic topic)
	{
		return topicDao.save(topic);
	}
	public GroupsTopic getTopicById(int topicId) throws ForumException{
		try
		{
		return topicDao.findById(topicId).get();
		}
		catch(Exception ex)
		{
			throw new ForumException("Oops!! Invalid topic Id.");
		}
	}
	public List<GroupsTopic> viewAllTopics()
	{
		return topicDao.findAll();
	}
	public GroupComment postComment(GroupComment comment) {
		return commentDao.save(comment);
		
	}
	public GroupMembers postRequest(GroupMembers request)
	{
		return memberDao.save(request);
	}
	public List<GroupMembers> getAllRequest()
	{
		return memberDao.findAll();
	}
	public RequestStatus postStatus(RequestStatus status) {
		return requestDao.save(status);
	}
	public String checkStatusById(String memberName){
		return requestDao.getRequestStatusById(memberName);
		
	}
	public List<GroupComment> postedComments()
	{
		return commentDao.findAll();
	}
	public ResponseEntity<Object> removeMember(int memberId) throws ForumException
    {
		try
		{
        Optional<GroupMembers> remove=memberDao.findById(memberId);
        memberDao.delete(remove.get());
        return ResponseEntity.ok().build();
		}
		catch(Exception ex)
		{
			throw new ForumException("Oops!! Invalid member Id.");
		}
    }
	public ResponseEntity<Object> removeGroup(int groupId) throws ForumException
    {
		try
		{
        Optional<Groups> remove=groupsDao.findById(groupId);
        groupsDao.delete(remove.get());
        return ResponseEntity.ok().build();
		}
		catch(Exception ex)
		{
			throw new ForumException("Oops!! Invalid group Id.");
		}
    }
	public ResponseEntity<Object> removeTopic(int topicId) throws ForumException
    {
		try
		{
        Optional<GroupsTopic> remove=topicDao.findById(topicId);
        topicDao.delete(remove.get());
        return ResponseEntity.ok().build();
		}
		catch(Exception ex)
		{
			throw new ForumException("Oops!! Invalid topic Id.");
		}
    }
	 public boolean validateMember(String memberName) {
	       
	        GroupMembers exists= memberDao.validateMember(memberName);
	        if(exists!=null) {
	            return true;
	           
	        }
	        else {
	            return false;
	        }
	        
	    }
	 public boolean validateTopic(String topicName) {
	       
	        GroupsTopic exists= topicDao.validateTopic(topicName);
	        if(exists!=null) {
	            return true;
	           
	        }
	        else {
	            return false;
	        }
	        
	    }
	

}
