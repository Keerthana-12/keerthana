package com.cg.forum.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.forum.beans.Admin;

public interface IGroupAdminDao extends JpaRepository<Admin,Integer> {

}
