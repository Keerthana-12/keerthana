package com.cg.ShareTrading_46008720.exception;

public class InvalidStockException extends RuntimeException{
	public InvalidStockException() {
		super();
	}

	public InvalidStockException(String message) {
		super(message);
	}

}
