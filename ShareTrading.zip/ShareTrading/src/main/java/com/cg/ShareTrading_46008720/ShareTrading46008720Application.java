package com.cg.ShareTrading_46008720;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShareTrading46008720Application {

	public static void main(String[] args) {
		SpringApplication.run(ShareTrading46008720Application.class, args);
	}

}
