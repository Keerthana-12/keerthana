package com.cg.ShareTrading_46008720.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ShareTrading_46008720.bean.Stock;
import com.cg.ShareTrading_46008720.exception.InvalidStockException;
import com.cg.ShareTrading_46008720.service.IStockService;
import com.cg.ShareTrading_46008720.service.StockService;




@RestController
@RequestMapping("api/v1")
public class StockController {
	
	@Autowired
	IStockService stock2=new StockService();
	
	@RequestMapping(method = RequestMethod.GET, value = "stock")
	List<Stock> viewAllStockkk(){
		return stock2.viewAllStockk();
		
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "stock")
	public Stock createStockkk(@RequestBody Stock stock) {
		
		return stock2.createStockk(stock);
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "stock/{id}")
	public Stock deleteStockkk(@PathVariable("id") int id) throws InvalidStockException{
		
		return stock2.deleteStockk(id);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "stock/{id}")
	public Stock getSingleStockkk(@PathVariable("id") int id) throws InvalidStockException{
		
		return stock2.getSingleStockk(id);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "stock/{id}")
	public Stock updateStockkk(@PathVariable("id") int id, @Valid @RequestBody Stock stock) throws InvalidStockException{
		
		return stock2.updateStock(stock);
	}
	
	

}
