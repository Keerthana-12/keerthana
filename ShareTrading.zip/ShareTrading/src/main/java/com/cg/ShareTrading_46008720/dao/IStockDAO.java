package com.cg.ShareTrading_46008720.dao;

import java.util.List;

import com.cg.ShareTrading_46008720.bean.Stock;

public interface IStockDAO {
	public Stock createStock(Stock stock);
	public Stock deleteStock(int id);
	public Stock getSingleStock(int id);
	public List<Stock> viewAllStock();
	public Stock updateStock(Stock stock);

}
