package com.cg.ShareTrading_46008720.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ShareTrading_46008720.bean.Stock;
import com.cg.ShareTrading_46008720.dao.IStockDAO;
import com.cg.ShareTrading_46008720.dao.StockDAO;
import com.cg.ShareTrading_46008720.exception.InvalidStockException;
 @Service
public class StockService implements IStockService{
	
	@Autowired
	IStockDAO stock1=new StockDAO();

	@Override
	public Stock createStockk(Stock stock) {
		
		return stock1.createStock(stock);
	}

	@Override
	public Stock deleteStockk(int id) throws InvalidStockException{
		
		return stock1.deleteStock(id);
	}

	@Override
	public Stock getSingleStockk(int id) throws InvalidStockException{
		
		return stock1.getSingleStock(id);
	}

	@Override
	public List<Stock> viewAllStockk() {
		
		return stock1.viewAllStock();
	}

	@Override
	public Stock updateStock(Stock stock) {
		
		return stock1.updateStock(stock);
	}

}
