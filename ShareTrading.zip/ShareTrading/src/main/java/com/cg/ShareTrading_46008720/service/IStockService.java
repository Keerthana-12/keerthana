package com.cg.ShareTrading_46008720.service;

import java.util.List;

import com.cg.ShareTrading_46008720.bean.Stock;

public interface IStockService {
	public Stock createStockk(Stock stock);
	public Stock deleteStockk(int id);
	public Stock getSingleStockk(int id);
	public List<Stock> viewAllStockk();
	public Stock updateStock(Stock stock);

}
