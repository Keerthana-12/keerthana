package com.cg.ShareTrading_46008720.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.ShareTrading_46008720.bean.Stock;


@Repository
public class StockDAO implements IStockDAO{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	public Stock createStock(Stock stock) {
		stock=createdata(stock);
		entityManager.persist(stock);
		
		return stock;
	}
	
	@Transactional
	public  Stock createdata(Stock stock)
	{
		int q=stock.getQuantity();
		double p=stock.getPrice();
		double a=p*q;
		double b;
		if(q>100)
		{
			b=(a*(0.3))/100;
		}
		else
		{
			b=(a*(0.5)/100);
		}
		stock.setAmount(a);
		stock.setBrokerage(b);
		return stock;
	}
	
	@Transactional
	public Stock deleteStock(int id)
	{
		Stock stock=entityManager.find(Stock.class, id);
		entityManager.remove(stock);
		return stock;
	}
	
	@Transactional
	public Stock getSingleStock(int id) {
		Stock stock=entityManager.find(Stock.class, id);
		return stock;
	}
	
	@Transactional
	public List<Stock> viewAllStock() {
		Query query = entityManager.createQuery("from Stock");
		return query.getResultList();
	}
	
	@Transactional
	public Stock updateStock(Stock stock) {
		entityManager.merge(stock);
		return stock;
	}
	public String m1() {
		
		System.out.println("entityManager"+ entityManager);
		return null;
		
	}
	

}
