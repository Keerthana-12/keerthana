import { Injectable } from '@angular/core';
import{ HttpClient} from "@angular/common/http"
import{IEmployee} from './employee.interface'

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  
  employees:IEmployee[];

  constructor(private http:HttpClient) {
    this.http.get<IEmployee[]>("assets/employee.json")
    .subscribe(data=>this.employees=data, error=>console.log(error));
   }
   getEmployees():IEmployee[]{
     return this.employees;
   }
   deleteEmployee(id:string){
     this.employees=this.employees.filter(emp=>emp.code!=id);
   }
   addEmployee(employee:IEmployee){
     this.employees.push(employee);
   }
}
