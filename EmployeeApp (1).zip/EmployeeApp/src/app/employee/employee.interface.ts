export interface IEmployee{
    code:string;
    gender:string;
    name:string;
    annualSalary:number;
    dateOfBirth:string;
}