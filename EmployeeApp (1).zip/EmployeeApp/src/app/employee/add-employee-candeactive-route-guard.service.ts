import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { AddEmployeeComponent } from './add-employee.component';

@Injectable({
  providedIn: 'root'
})
export class AddEmployeeCandeactiveRouteGuardService implements CanDeactivate <AddEmployeeComponent> {

  constructor() { }

  canDeactivate(component: AddEmployeeComponent): boolean {
    
    if(component.EmployeeForm.dirty){
      return confirm("Are you sure ?");
    }
    return true;
  };
}
