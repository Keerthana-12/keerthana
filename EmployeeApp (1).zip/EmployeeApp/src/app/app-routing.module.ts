import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddEmployeeComponent } from './employee/add-employee.component';
import { EmployeeListComponent } from './employee/employee-list.component';
import { PageNotFoundComponent } from './employee/page-not-found.component';
import { AddEmployeeCandeactiveRouteGuardService } from './employee/add-employee-candeactive-route-guard.service';


const routes: Routes = [
  {path:'add',component:AddEmployeeComponent, canDeactivate:[AddEmployeeCandeactiveRouteGuardService]},
  {path:'employees',component:EmployeeListComponent},
  {path:'',redirectTo:'/employees',pathMatch:'full'},
  {path:'**', component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
