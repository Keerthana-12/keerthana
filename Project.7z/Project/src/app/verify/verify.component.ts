import { Component, OnInit, Input } from '@angular/core';
import { CapbookService } from '../capbook.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-verify',
  templateUrl: './verify.component.html',
  styleUrls: ['./verify.component.css']
})
export class VerifyComponent implements OnInit {
 // @Input() email: string

  constructor(private capbookService:CapbookService,private router:Router) { }

  ngOnInit() {
  }
  verifyEmail(email){
    //this.userDetails.email=email;
    this.capbookService.verifyEmail(email).subscribe(data=>{
      if(data===true){
       this.router.navigate(['ForgetPassword'])
      }else{
      window.alert("You Have Entered An Invalid Mail Id");}
  
    });

}}
