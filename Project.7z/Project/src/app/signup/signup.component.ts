import { Component, OnInit } from '@angular/core';
import{CapbookService} from '../capbook.service'; 
import {FormBuilder, Validators } from '@angular/forms';
import { User } from '../user';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  userDetails: User;

  constructor(private capbookService:CapbookService) {
    this.userDetails=new User();
  
   
  }

  ngOnInit() {
    
  }
  createUser(userId,firstName,lastName,email,password,confirmPassword,birthDate,phoneNo):void{
    this.userDetails.userId=userId;
    this.userDetails.firstName=firstName;
    this.userDetails.lastName=lastName;
    this.userDetails.email=email;
    this.userDetails.password=password;
    this.userDetails.confirmPassword=confirmPassword;
    this.userDetails.birthDate=birthDate;
    this.userDetails.phoneNo=phoneNo;
    if(password==confirmPassword){

    
    this.capbookService.createUser(this.userDetails).subscribe(data=>{
      alert("User added Successfully.");
    });
  }
  else{
    alert("Password and confirmPassword doesn't matched...")
  }
  }

}
