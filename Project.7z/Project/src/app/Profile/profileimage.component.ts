import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profileimage',
  templateUrl: './profileimage.component.html',
  styleUrls: ['./profileimage.component.css']
})
export class ProfileimageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
