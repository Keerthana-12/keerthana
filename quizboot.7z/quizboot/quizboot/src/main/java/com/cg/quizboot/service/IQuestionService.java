package com.cg.quizboot.service;

import java.util.List;

import com.cg.quizboot.model.Questions;

public interface IQuestionService {
	public Questions createStock(Questions ques);
	public Questions deleteStock(int id);
	public Questions getSingleStock(int id);
	public List<Questions> viewAllStock();
	public Questions updateStock(Questions stock);
}
