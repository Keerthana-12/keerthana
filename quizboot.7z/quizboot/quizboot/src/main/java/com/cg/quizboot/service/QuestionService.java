package com.cg.quizboot.service;

import java.util.List;

import org.aspectj.weaver.patterns.TypePatternQuestions.Question;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.quizboot.dao.IQuestionDao;
import com.cg.quizboot.model.Questions;

@Service
public class QuestionService implements IQuestionService{
	@Autowired
	IQuestionDao quesDao;
	
	public Questions createStock(Questions ques) {
		
		return quesDao.createStock(ques);
	}

	
	public Questions deleteStock(int id) {
		
		return quesDao.deleteStock(id);
	}

	
	public Questions getSingleStock(int id) {
	
		return quesDao.getSingleStock(id);
	}

	
	public List<Questions> viewAllStock() {
		
		return quesDao.viewAllStock();
	}

	
	public Questions updateStock(Questions ques) {
	
		return quesDao.updateStock(ques);
	}

}
