package com.cg.quizboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cg.quizboot.model.Questions;
import com.cg.quizboot.service.IQuestionService;

@RestController
@RequestMapping("api/v1")
public class QuestionsController {
	@Autowired
	IQuestionService service;

	@RequestMapping(method = RequestMethod.POST, value = "CreateQuestion")

	public Questions create(@RequestBody Questions ques) {

		return service.createStock(ques);
	}
	@RequestMapping(method = RequestMethod.GET, value = "ViewAllQuestions")
	public List<Questions> list(){
		
		return service.viewAllStock();
	}
	@RequestMapping(method = RequestMethod.GET, value = "FindSingleQuestion/{id}")
	public Questions get(@PathVariable("id") int id){
		
		return service.getSingleStock(id);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "UpdateQuestion/{id}")
    public Questions update(@PathVariable("id") int id, @RequestBody Questions ques) {
        return service.updateStock(ques);
    }
	
	@RequestMapping(method = RequestMethod.DELETE, value = "DeleteQuestion/{id}")
    public Questions delete(@PathVariable("id") int id) {
        return service.deleteStock(id);
    }
}
