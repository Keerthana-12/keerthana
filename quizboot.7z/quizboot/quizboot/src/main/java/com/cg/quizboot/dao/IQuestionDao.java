package com.cg.quizboot.dao;

import java.util.List;

import com.cg.quizboot.model.Questions;

public interface IQuestionDao {
	public Questions createStock(Questions ques);
	public Questions deleteStock(int id);
	 public Questions getSingleStock(int id);
	 public List<Questions> viewAllStock();
	 public Questions updateStock(Questions ques);
	
}
