package com.cg.quizboot.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;


import com.cg.quizboot.model.Questions;

@Repository
public class QuestionDao implements IQuestionDao {
	
	@PersistenceContext
    private EntityManager entityManager;
	
	@Transactional
    public Questions createStock(Questions ques) {
        
        entityManager.persist(ques);
        
        return ques;
    }
	 @Transactional
	    public Questions deleteStock(int id)
	    {
		 Questions ques=entityManager.find(Questions.class, id);
	        entityManager.remove(ques);
	        return ques;
	    }
	    
	    @Transactional
	    public Questions getSingleStock(int id) {
	    	Questions ques=entityManager.find(Questions.class, id);
	        return ques;
	    }
	    
	    @Transactional
	    public List<Questions> viewAllStock() {
	        Query query = entityManager.createQuery("from Questions");
	        return query.getResultList();
	    }
	    
	    @Transactional
	    public Questions updateStock(Questions ques) {
	        entityManager.merge(ques);
	        return ques;
	    }
	 
}
