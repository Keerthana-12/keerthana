package com.cg.quizboot.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Quiz3Questions")
public class Questions {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	Integer questionId;
	@Column
	String question;
	@Column
	String option;
	
	
	public Questions(int questionId, String question) {
		this.questionId = questionId;
		this.question = question;
	}


	public Questions() {}


	public int getQuestionId() {
		return questionId;
	}


	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}


	public String getQuestion() {
		return question;
	}


	public void setQuestion(String question) {
		this.question = question;
	}


	@Override
	public String toString() {
		return "Questions [questionId=" + questionId + ", question=" + question + "]";
	}
	
}
