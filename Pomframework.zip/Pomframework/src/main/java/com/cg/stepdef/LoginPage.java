package com.cg.stepdef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
    WebDriver driver;
	@FindBy(xpath="//*[@id=\"desktop-header-cnt\"]/div[2]/div[2]/div/div[1]/span[2]")
	WebElement profile;
	@FindBy(xpath="//*[@id=\"desktop-header-cnt\"]/div[2]/div[2]/div/div[2]/div[2]/div[2]/div[1]/a[2]")
	WebElement login;
	@FindBy(name="email" )
	WebElement username;
	@FindBy(name="password" )
	WebElement password;
	@FindBy(xpath="//*[@id=\"mountRoot\"]/div/div/div/form/fieldset[2]/button")
	WebElement submit;
	
	
	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	public void clickProfile()
	{
		profile.click();
	}
    public void clickLogin()
    {
    	login.click();
    }
    public void enterCredentials()
    {
    	username.sendKeys("ramyavenky1998@gmail.com");
    	password.sendKeys("R@amya@1");
    }
    public void clickSubmit()
    {
    	submit.click();
    }
}
