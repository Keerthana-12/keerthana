package com.cg.stepdef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	WebDriver driver;
	 LoginPage login;
	@Given("^user is on myntra login page$")
	public void user_is_on_myntra_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KEMADHES\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notifications");
		 driver=new ChromeDriver(options);
		 driver.get("http://www.myntra.com");
		 driver.manage().window().maximize();
		 login=new LoginPage(driver);
		 login.clickProfile();
		 login.clickLogin();
}
	@When("^user enters username and password$")
    public void user_enters_username_and_password() throws Throwable {
		
		login.enterCredentials();
	}
	
	@When("^user clicks on submit$")
	public void user_clicks_on_submit() throws Throwable {
		
		login.clickSubmit();
	}

	@Then("^Home page must appear$")
	public void home_page_must_appear() throws Throwable {
	  
		System.out.println(driver.getTitle());
	}

}
