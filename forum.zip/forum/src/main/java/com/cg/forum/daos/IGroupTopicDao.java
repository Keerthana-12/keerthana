package com.cg.forum.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.forum.beans.GroupsTopic;

public interface IGroupTopicDao extends JpaRepository<GroupsTopic,Integer> {

}
