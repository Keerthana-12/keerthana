package com.cg.bankapp.view;
import java.util.List;
import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bankapp.entity.TransactionDetails;
import com.cg.bankapp.service.BankServiceImpl;
public class User {
	
		public static void main(String[] args) {
			
		    Scanner scanner  = new Scanner(System.in);      
            ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
   		    BankServiceImpl bankService =  context.getBean("bankService",BankServiceImpl.class);
	        int option;
			int obj,balance;
			String name,passwrd,contactNo;
			while(true)
			{
			
				System.out.println(" Welcome to XYZ bank!!! ");
				System.out.println("Please select Your Option");
				System.out.println("1.CREATE NEW ACCOUNT");
				System.out.println("2.SHOW BALANCE");
				System.out.println("3.DEPOSIT");
				System.out.println("4.WITHDRAW");
				System.out.println("5.TRANSFER AMOUNT");
				System.out.println("6.PRINT TRANSACTIONS");
				System.out.println("7.EXIT");
				option = scanner.nextInt();
				switch (option) {
				case 1:
					System.out.println("Welcome to XYZ Bank");
					do
					{
						System.out.println("Enter your name: ");
						name = scanner.next();
						obj =bankService.nameValidate(name);
					}
					while(obj!=1);
					do
					{
						System.out.println("Enter your mobile number: ");
						contactNo = scanner.next();
						obj = bankService.mobNoValidate(contactNo);
					}
					while(obj!=1);
					long accNo = (long) (Math.random()*1234);
					do
					{
						System.out.println("Create 4 digit Pin: ");
						passwrd = scanner.next();
						obj = bankService.passwordValidate(passwrd);
					}
					while(obj!=1);
					do
					{
						System.out.println("Enter the amount: ");
						balance = scanner.nextInt();
						obj = bankService.checkBalance(balance);
					}
					while(obj!=1);
					boolean result =  bankService.createAccount(name,contactNo,passwrd,accNo,balance);
					if(result)
					{
						System.out.println("Your Account has been created successfully: "+accNo);
					}
					break;
				case 2:
					System.out.println("Enter your account number: ");
					accNo = scanner.nextLong();
					System.out.println("Enter your 4 digit Pin");
					passwrd = scanner.next();
					boolean bank1= bankService.validateAccount(accNo,passwrd);
					if(bank1)
					{
							balance = bankService.showBalance(accNo);
							if(balance!=0)
							{
								System.out.println("Your Current balance is: "+balance);
							}
							else
							{
								System.out.println("Error occured");
							}
					}
					else
					{
						System.out.println("Invalid details..Please Check again..");
					}
					break;
				
				case 3:
					System.out.println("Enter your account number");
					accNo = scanner.nextLong();
					System.out.println("Enter your 4 digit Pin");
					passwrd = scanner.next();
					boolean bank2= bankService.validateAccount(accNo,passwrd);
					if(bank2)
					{
						System.out.println("Enter the amount to be deposited");
						int deposit = scanner.nextInt();
						balance = bankService.depositAmount(accNo,deposit);
						System.out.println("Amount is deposited to your account successfully");
						System.out.println("your current balance is "+balance);
					}
					else
					{
						System.out.println("Invalid details..Please Check again..");
					}
					break;
				
				case 4:
					System.out.println("Enter your account number");
					accNo = scanner.nextLong();
					System.out.println("Enter your 4 digit Pin");
					passwrd = scanner.next();
					bank2= bankService.validateAccount(accNo,passwrd);
					if(bank2)
					{
						balance = bankService.showBalance(accNo);
						System.out.println("Your current balance is "+balance);
						System.out.println("Enter the amount to be withdraw");
						int withdraw = scanner.nextInt();
							balance = bankService.withdrawAmount(accNo,withdraw);
							if(balance>=0)
							{
								System.out.println("Amount has been withdrawn from your account");
						
								System.out.println("Your new account balance is "+balance+"\n");
							}
							else
							{
                                 System.out.println("Insufficient Balance");
							}
						}
						
					
					else
					{
				               System.out.println("Invalid details..Please Check again..");
					}
					break;
				
				case 5:
					System.out.println("Enter the senders account number");
					accNo = scanner.nextLong();
					System.out.println("Enter your 4 digit Pin");
					passwrd = scanner.next();
					bank2 = bankService.validateAccount(accNo,passwrd);
					if(bank2)
					{
						System.out.println("\nEnter the receivers account number");
						long  accno = scanner.nextLong();
						System.out.println("Enter the amount you want to transfer");
						int amount = scanner.nextInt();
						boolean transfer = bankService.fundTransfer(accNo, accno, amount);
						if(transfer)
						{
							System.out.println(amount+ " amount has been transferred successfully...");
						}
						else
						{
						  System.out.println("Problem Occurred During transaction...");
						}
					}
					else
					{
						System.out.println("Invalid details..Please Check again..");
					}
					break;
				
				case 6:
					System.out.println("Enter your account number");
					accNo = scanner.nextLong();
					System.out.println("Enter your 4 digit Pin");
					passwrd = scanner.next();
					bank2 = bankService.validateAccount(accNo,passwrd);
					if(bank2)
					{
	                    List<TransactionDetails> trans=bankService.getTransaction(accNo);

						System.out.println("Transaction Statement \n");

						for(TransactionDetails tran:trans)
						{
							System.out.println(tran);
						}
					}
					else 
					{
						System.out.println("Invalid Details..Please Check again..");
					}
					break;
				
				case 7: 
					System.out.println("Thank you for using our Services");
	               System.exit(0);
					break; 
					
				default: 
                System.out.println("kindly select the existing options");
                break;
	            }
			}
	}
}
