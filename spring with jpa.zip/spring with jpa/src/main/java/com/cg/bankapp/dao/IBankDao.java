package com.cg.bankapp.dao;

import java.util.List;

import com.cg.bankapp.entity.BankDetails;
import com.cg.bankapp.entity.TransactionDetails;

public interface IBankDao {
   boolean createAccount(BankDetails bank);
   int showBalance(long accountNo);
   int depositAmount(long accountNo, int deposit);
   int withdrawAmount(long accountNo, int withdraw) ;
   boolean fundTransfer(long accountNo, long accno, int amount);
   boolean validateAccount(long accountNo,String password);
	public List<TransactionDetails> getTransactions(long accountNo) ;
	


}
