import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { ForumService } from '../forum.service';

@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {
member:User;
  constructor(private forumService:ForumService) {
    this.member=new User();
   }

  ngOnInit() {
  }
  postComment(topicId,memberName,commentText):void {
    this.member.topicId=topicId;
    this.member.memberName=memberName;
    this.member.commentText=commentText; 
    this.forumService.postComment(this.member).subscribe(data => {
    alert("Your comment is posted.");
    });
}
}
