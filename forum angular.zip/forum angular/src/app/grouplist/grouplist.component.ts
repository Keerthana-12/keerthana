import { Component, OnInit } from '@angular/core';
import { ForumService } from '../forum.service';

@Component({
  selector: 'app-grouplist',
  templateUrl: './grouplist.component.html',
  styleUrls: ['./grouplist.component.css']
})
export class GrouplistComponent implements OnInit {
groups;
  constructor(private forumService:ForumService) {
    forumService.getAllGroupDetails().subscribe((res) => this.groups=res)
   }

  ngOnInit() {
  }

}
