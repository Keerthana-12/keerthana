export class User
{
    public groupId:number;
    public groupName:string;
    public groupAdmin:string;
    public topicId:number;
    public topicName:string;
    public memberName:string;
    public commentText:string;
    public postedDate:Date;
}