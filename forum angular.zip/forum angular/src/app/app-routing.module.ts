import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { GroupComponent } from './group/group.component';
import { TopicComponent } from './topic/topic.component';
import { CommentComponent } from './comment/comment.component';
import { GrouplistComponent } from './grouplist/grouplist.component';
import { TopiclistComponent } from './topiclist/topiclist.component';


const routes: Routes = [
  {path:'',component:HomepageComponent},
  {path:'group',component:GroupComponent},
  {path:'topic',component:TopicComponent},
  {path:'comment',component:CommentComponent},
  {path:'grouplist', component:GrouplistComponent},
  {path:'topiclist',component:TopiclistComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
