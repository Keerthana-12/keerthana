import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListIcecreamComponent } from './order/list-icecream.component';
import { SuccessComponent } from './order/success.component';


const routes: Routes = [
  {path:"list",component:ListIcecreamComponent},
  {path:"success/:name/:price",component:SuccessComponent},
  {path:'',redirectTo:'/list',pathMatch:"full"}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
