import { Component, OnInit } from '@angular/core';
import { OrderService } from './order.service';
import {ActivatedRoute} from '@angular/router'

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {
  balance:number;
  iceCreamName:string;
  constructor(private orderservice:OrderService,private activaterRoute:ActivatedRoute) { }

  ngOnInit() {
    /* this.balance=this.orderservice.getBalance(); */
    this.iceCreamName =this.activaterRoute.snapshot.params['name'];
    let price:number=this.activaterRoute.snapshot.params['price'];
    this.balance=this.orderservice.getBalance()-price;
    if(this.balance>=0){
    this.orderservice.balace=this.balance;
    
    }
    
    
  }

}
