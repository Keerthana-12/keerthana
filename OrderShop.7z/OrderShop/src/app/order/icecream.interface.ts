export interface Icecream{
    icecreamId:number;
    icecreamName:string;
    price:number;
}