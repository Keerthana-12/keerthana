import { Component, OnInit } from '@angular/core';
import { OrderService } from './order.service';
import { Icecream } from './icecream.interface';

@Component({
  selector: 'app-list-icecream',
  templateUrl: './list-icecream.component.html',
  styleUrls: ['./list-icecream.component.css']
})
export class ListIcecreamComponent implements OnInit {

  icecreams:Icecream[];
  balance:number

  constructor(private orderservice:OrderService) { }

  ngOnInit() {
    setTimeout(() => {
      this.icecreams=this.orderservice.getIcecreams();
    }, 10);
    this.balance =this.orderservice.getBalance();
    
  }

}
