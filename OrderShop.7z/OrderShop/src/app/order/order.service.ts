import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Icecream } from './icecream.interface';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  icecreams:Icecream[];
  balace:number=600;
  constructor(private http:HttpClient) {
    this.http.get<Icecream[]>("assets/icecreamList.json")
    .subscribe(data=>this.icecreams=data, error=>console.log(error));
    
  
   }
   getIcecreams():Icecream[]{
     return this.icecreams;
   }
   getBalance(){
     return this.balace;
   }
}
