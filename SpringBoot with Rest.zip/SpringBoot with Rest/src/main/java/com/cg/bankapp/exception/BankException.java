package com.cg.bankapp.exception;

public class BankException extends Exception {
public BankException()
{
	super();
}
public BankException(String msg)
{
	super(msg);
}
}

