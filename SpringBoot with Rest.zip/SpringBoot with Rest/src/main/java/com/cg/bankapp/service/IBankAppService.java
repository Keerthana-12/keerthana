package com.cg.bankapp.service;


import com.cg.bankapp.bean.BankDetails;
import com.cg.bankapp.bean.TransactionDetails;
import com.cg.bankapp.exception.BankException;


public interface IBankAppService 
{	
	public void getDetailsbyLogin(String username,String password)throws BankException;
	public BankDetails addBankAccount(BankDetails bank) throws BankException;
	public double showBalance(int accountId) throws BankException;
	public double depositAmount(int accountId,double deposit) throws BankException;
	public double withdrawAmount(int accountId,double withdraw) throws BankException;
	public BankDetails cashTransfer(int source,int destination,double money) throws BankException;
	public TransactionDetails PrintTransaction(int accountNumber);		
}
