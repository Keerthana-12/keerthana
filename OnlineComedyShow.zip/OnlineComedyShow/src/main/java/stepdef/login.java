package stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class login {

	@FindBy(xpath = "//*[@id=\"Text24\"]")
	WebElement showid;
	@FindBy(xpath = "//*[@id=\"Text1\"]")
	WebElement title;
	@FindBy(xpath = "//*[@id=\"Text12\"]")
	WebElement releasedate;
	@FindBy(xpath = "//*[@id=\"Text14\"]")
	WebElement comedian;
	@FindBy(xpath = "//*[@id=\"Text15\"]")
	WebElement duration;
	@FindBy(xpath = "//*[@id=\"Select12\"]")
	WebElement language;
	@FindBy(xpath = "//*[@id=\"Select9\"]")
	WebElement rating;
	@FindBy(xpath = "//*[@id=\"Button4\"]")
	WebElement add;
	

	public login(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	public void enterid(String s) {
		showid.sendKeys(s);
	}
	public void entertitle(String s) {
		title.sendKeys(s);
	}
	public void enterdate(String s) {
		releasedate.sendKeys(s);
	}
	public void entercomedian(String s) {
		comedian.sendKeys(s);
	}
	public void enterduration(String s) {
		duration.sendKeys(s);
	}
	public void enterlanguage(String s) {
		Select select=new Select(language);
		select.selectByValue(s);
	}
	public void enterrating(String s) {
		Select select=new Select(rating);
		select.selectByValue(s);	
	}
	public void addshow() {
		add.click();
	}
	

}
