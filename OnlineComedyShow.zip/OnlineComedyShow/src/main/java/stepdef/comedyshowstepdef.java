package stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class comedyshowstepdef {
	WebDriver driver;
	Actions actions;
	login log;
	
	@Given("^user is on comedy website$")
	public void user_is_on_comedy_website() throws Throwable {
   System.setProperty("webdriver.chrome.driver","C:\\Users\\PPOOJA\\Documents\\chromedriver.exe");
		
	    driver=new ChromeDriver();
	    log=new login(driver);
	    actions=new Actions(driver);
		driver.manage().window().maximize();
		driver.get("C:\\Users\\PPOOJA\\Downloads\\ComedyShow.html");	
		Assert.assertEquals(driver.getTitle(),"Add ComedyShow Form");
		
	}

	@When("^user enters the \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_the_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7) throws Throwable {
	    
	    
	    log.enterid(arg1);
	    
		log.entertitle(arg2);
		
	    log.enterdate(arg3);
	   
	    log.entercomedian(arg4);
	   
	    log.enterduration(arg5);
	    
	    log.enterlanguage(arg6);
	    
	    log.enterrating(arg7);
	  
	}

	@When("^user clicks on Add ComedyShow$")
	public void user_clicks_on_Add_ComedyShow() throws Throwable {
	    log.addshow();
	}

	@Then("^successfully logged page must appear$")
	public void successfully_logged_page_must_appear() throws Throwable {
	     
	}

  
	
	 
	

	
}
