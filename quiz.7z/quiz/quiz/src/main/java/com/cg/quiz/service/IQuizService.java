package com.cg.quiz.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.cg.quiz.model.QuestionsTable;

public interface IQuizService {
	List<QuestionsTable> list();
	public QuestionsTable createQuestions(@RequestBody QuestionsTable quiz);
	public ResponseEntity<?> deleteNote(@PathVariable(value="Id")Integer noteId);
	 public QuestionsTable updateNote(@PathVariable(value="id") Integer noteId,@Valid @RequestBody QuestionsTable quiz);
	 public QuestionsTable get(@PathVariable("id") Integer id);
}
