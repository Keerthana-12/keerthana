package com.cg.quiz.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.quiz.model.QuestionsTable;

public interface IQuizDao extends JpaRepository<QuestionsTable, Integer>{

}
