package com.cg.quiz.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

//import com.cg.onlineeducation.model.Quiz;
import com.cg.quiz.dao.IQuizDao;
import com.cg.quiz.model.QuestionsTable;

@Service
public class QuizService implements IQuizService {
	@Autowired
	IQuizDao daoObj;

	public List<QuestionsTable> list() {
		return daoObj.findAll();
	}

	public QuestionsTable createQuestions(@RequestBody QuestionsTable quiz) {
		return daoObj.save(quiz);
	}
	 //@RequestMapping(method = RequestMethod.DELETE, value = "quiz/{Id}")
	 
	 public ResponseEntity<?> deleteNote(@PathVariable(value="Id")Integer noteId)
	 {
	 Optional<QuestionsTable>optional=daoObj.findById(noteId);
	 daoObj.delete(optional.get());
	 return ResponseEntity.ok().build();
    }
	 //@RequestMapping(method = RequestMethod.PUT, value = "quiz/{id}")
	    public QuestionsTable updateNote(@PathVariable(value="id") Integer noteId,@Valid @RequestBody QuestionsTable quiz){
	      Optional<QuestionsTable>optional=daoObj.findById(noteId);
	      QuestionsTable existing=optional.get();
	      BeanUtils.copyProperties(quiz,existing);
	      
			return daoObj.save(existing);
	
}
	    //@RequestMapping(method = RequestMethod.GET, value = "quiz/{id}")
public QuestionsTable get(@PathVariable("id") Integer id){
	Optional<QuestionsTable>optional=daoObj.findById(id);

	return optional.get();
}

		
	    }
