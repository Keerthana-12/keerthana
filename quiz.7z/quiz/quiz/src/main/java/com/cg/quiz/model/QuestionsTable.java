package com.cg.quiz.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name="QuizTable1")
public class QuestionsTable {
	@Id
	@GeneratedValue
	private int questionNumber;
	@Column
	private String Question;
	public int getQuestionNumber() {
		return questionNumber;
	}
	public void setQuestionNumber(int questionNumber) {
		this.questionNumber = questionNumber;
	}
	public String getQuestion() {
		return Question;
	}
	public void setQuestion(String question) {
		Question = question;
	}
	@Override
	public String toString() {
		return "QuestionsTable [questionNumber=" + questionNumber + ", Question=" + Question + "]";
	}


}
