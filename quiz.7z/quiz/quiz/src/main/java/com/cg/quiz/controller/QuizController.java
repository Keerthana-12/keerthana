package com.cg.quiz.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cg.quiz.model.QuestionsTable;
import com.cg.quiz.service.IQuizService;

@RestController
@RequestMapping("api/v1")
public class QuizController {
	
	@Autowired
	private IQuizService serviceObj;
	
	@RequestMapping(method = RequestMethod.GET, value = "quiz")
	List<QuestionsTable> list(){		
		return serviceObj.list();
	}
	@RequestMapping(method = RequestMethod.POST, value = "quiz")
	public QuestionsTable create(@RequestBody QuestionsTable quiz) {		
		
		return serviceObj.createQuestions(quiz);
	}
	 @RequestMapping(method = RequestMethod.DELETE, value = "quiz/{Id}")
	 public ResponseEntity<?> delete(@PathVariable(value="Id")Integer noteId) {
		return serviceObj.deleteNote(noteId);
		 
	 }
	 @RequestMapping(method = RequestMethod.PUT, value = "quiz/{id}")
	    public QuestionsTable updateNote(@PathVariable(value="id") Integer noteId,@Valid @RequestBody QuestionsTable quiz){
			return serviceObj.updateNote(noteId, quiz);
	 
	 }
	@RequestMapping(method = RequestMethod.GET, value = "quiz/{id}")
	 public QuestionsTable get(@PathVariable("id") Integer id)
	 {
		return serviceObj.get(id);
	 }
}
