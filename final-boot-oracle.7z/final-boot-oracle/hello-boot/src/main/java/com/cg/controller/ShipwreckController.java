package com.cg.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Shipwreck;
import com.cg.repository.Shipwreckrepo;

@RestController
@RequestMapping("api/v1")
public class ShipwreckController {
	
	@Autowired
	private Shipwreckrepo shipwreckk;
	
	@RequestMapping(method = RequestMethod.GET, value = "shipwrecks")
	List<Shipwreck> list(){
		System.out.println("inside list() method call");
		
		return shipwreckk.findAll();
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "shipwrecks")
	public void create(@RequestBody Shipwreck shipwreck) {
		shipwreckk.save(shipwreck);
		
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "shipwrecks/{id}")
	public Shipwreck get(@PathVariable("id") long id){
		Optional<Shipwreck> optional=shipwreckk.findById(id);
	    return optional.get();
	}
	
	/*@RequestMapping(method = RequestMethod.DELETE, value = "shipwrecks")
	public void delete(@PathVariable("id") long id) {
		Shipwreck ship=shipwreckk.getOne(id);
		
		shipwreckk.delete(ship);
		
	}

	@RequestMapping(method = RequestMethod.PUT, value = "shipwrecks/{id}")
	public void update(@PathVariable("id") long id, @RequestBody Shipwreck shipwreck) {
		shipwreckk.save(shipwreck);
		
	}
	
	*/
	
	@RequestMapping(method=RequestMethod.DELETE,value="shipwrecks/{id}")
	public ResponseEntity<?> deleteNote(@PathVariable(value="id") Long id){
		Optional<Shipwreck> optionalWreck=shipwreckk.findById(id);
		shipwreckk.delete(optionalWreck.get());
		return ResponseEntity.ok().build();
		
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="shipwrecks/{id}")
	public Shipwreck updateNote(@PathVariable(value="id") long id,@Valid @RequestBody Shipwreck wreck) {
		Optional<Shipwreck> optionalWreck=shipwreckk.findById(id);
		Shipwreck existingWreck=optionalWreck.get();
		BeanUtils.copyProperties(wreck, existingWreck);
		shipwreckk.saveAndFlush(existingWreck);
		return existingWreck;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
